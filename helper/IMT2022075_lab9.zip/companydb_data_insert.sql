insert into EMPLOYEE(Fname, Minit, Lname, Ssn, Bdate, Address, Sex, Salary, Super_ssn, Dno)
VALUES ('John','B','Smith','123456789','1965-01-09','731, Fondren, Houston, TX','M',30000,NULL,NULL);

insert into EMPLOYEE(Fname, Minit, Lname, Ssn, Bdate, Address, Sex, Salary, Super_ssn, Dno)
VALUES ('Amrita','B','lawrence','987654321','1965-04-09','734, Fondren, Houston, TX','F',25000,NULL,NULL);

insert into DEPARTMENT(dname, dnumber, mgr_ssn, mgr_start_date)
VALUES ('Research', 1 , NULL , '1995-04-09');

insert into DEPT_LOCATIONS(Dnumber, Dlocation)
VALUES (1,'Houston');

insert into PROJECT(Pname, Pnumber, Plocation, Dnum )
VALUES ('ProductX',1,'Bellare',NULL);

insert into WORKS_ON(Essn , Pno, Hours )
VALUES ('123456789', 1, 32.5);

insert into DEPENDENT(Essn, Dependent_name, Sex, Bdate, Relationship)
VALUES ('987654321','Bob','M','1986-04-05','Son');