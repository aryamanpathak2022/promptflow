alter table EMPLOYEE
    add constraint fk_Super_ssn FOREIGN KEY (Super_ssn)
REFERENCES EMPLOYEE(Ssn);

alter table EMPLOYEE
    add constraint fk_Dno FOREIGN KEY (Dno)
REFERENCES DEPARTMENT(dnumber);

alter table DEPARTMENT
    add constraint fk_mgr_ssn FOREIGN KEY (mgr_ssn)
REFERENCES EMPLOYEE(Ssn);

alter table DEPT_LOCATIONS
    add constraint fk_Dnumber FOREIGN KEY (Dnumber)
REFERENCES DEPARTMENT(dnumber);

alter table PROJECT
    add constraint fk_Dnum FOREIGN KEY (Dnum)
REFERENCES DEPARTMENT(dnumber);

alter table WORKS_ON
    add constraint fk_Essn_workson FOREIGN KEY (Essn)
REFERENCES EMPLOYEE(Ssn);

alter table WORKS_ON
    add constraint fk_Pno FOREIGN KEY (Pno)
REFERENCES PROJECT(Pnumber);

alter table DEPENDENT
    add constraint fk_Essn_dependent FOREIGN KEY (Essn)
REFERENCES EMPLOYEE(Ssn);


