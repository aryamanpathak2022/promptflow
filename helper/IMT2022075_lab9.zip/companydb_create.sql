create table DEPARTMENT(
    dname varchar(30) NOT NULL,
    dnumber smallint,
    mgr_ssn char(9),
    mgr_start_date date,
    constraint pk_department PRIMARY KEY (dnumber)
);

create table EMPLOYEE(
    Fname varchar(30) NOT NULL,
    Minit char(1),
    Lname varchar(30),
    Ssn char(9),
    Bdate date,
    Address varchar(50),
    Sex char(1),
    Salary Bigint,
    Super_ssn char(9),
    Dno smallint,
    constraint pk_employee PRIMARY KEY (Ssn)
);

create table DEPT_LOCATIONS(
    Dnumber smallint,
    Dlocation varchar(30),
    constraint pk_dept_locations PRIMARY KEY(Dnumber,Dlocation)
);

create table WORKS_ON(
    Essn char(9),
    Pno mediumint,
    Hours Decimal(3,1),
    constraint pk_works_on PRIMARY KEY(Essn,Pno)
);

create table PROJECT(
    Pname varchar(30),
    Pnumber mediumint,
    Plocation varchar(30),
    Dnum smallint,
    constraint pk_project PRIMARY KEY(Pnumber)
);

create table DEPENDENT(
    Essn char(9),
    Dependent_name varchar(30),
    Sex char(1),
    Bdate date,
    Relationship varchar(30),
    constraint pk_dependent PRIMARY KEY(Essn,Dependent_name)
);

