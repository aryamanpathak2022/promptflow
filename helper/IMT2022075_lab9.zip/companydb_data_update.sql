update EMPLOYEE
set super_ssn = '987654321', dno=1
where ssn='123456789';

update EMPLOYEE
set super_ssn = '123456789', dno=1
where ssn='987654321';

update DEPARTMENT
set mgr_ssn = '123456789'
where dnumber = 1;

update PROJECT
set Dnum = 1
where Pnumber = 1;